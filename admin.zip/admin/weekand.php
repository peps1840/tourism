<?php
	session_start();
	include('headad.php');
	
?>
<form action='insertweekand.php' method='post' enctype='multipart/form-data'>
<fieldset  style='border:3px solid crimson;width:80%''>
<legend>ADD WEEKAND PLACES</legend>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' width='70%'>
<tr>
	<td colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		ADD WEEKEND PLACES
	
	</td>

</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>
<tr>
	<td  colspan='2'  align='center' style='color:red'>
		<?php
			if(isset($_SESSION["err9"]))
				echo $_SESSION["err9"];
		
		?>
	
	</td>

</tR>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>

	
<tr>
	<td>PLACE NAME</td>
	<td><input type='text' name='t1' value=''>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>

<tr>
	<td>PHOTO</td>
	<td><input type='file' name='photo'></td>
</tr>	
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr align='center'>
	<td><input type='submit' value='send' ></td>
</tr>
	
	
</table>
</fieldset>
</form>
<?php
$_SESSION["err9"]="";
include('footerad.php');
?>