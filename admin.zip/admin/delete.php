<?php
session_start();
include('config.php');
$id=$_GET["a"];
$sql=mysql_query("delete from adddes where id='$id'");

if($sql)
{
	$_SESSION["err3"]="Delete Successfully";
	header("location:viewplace.php");
}
?>

