<?php
session_start();
$ch = curl_init();
include('config.php');

$sql="select * from register order by id desc";
$r=mysql_query($sql);
$news=mysql_real_escape_string($_REQUEST["a1"]);
while($row=mysql_fetch_array($r))
{
$user="divyansen@gmail.com:876411";
$receipientno="$row[3]";
$senderID="TEST SMS";
$msgtxt="$news";
curl_setopt($ch,CURLOPT_URL,  "http://api.mVaayoo.com/mvaayooapi/MessageCompose");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "user=$user&senderID=$senderID&receipientno=$receipientno&msgtxt=$msgtxt");
$buffer = curl_exec($ch);

}

$news=mysql_real_escape_string($_REQUEST["a1"]);
$des=mysql_real_escape_string($_REQUEST["add"]);

$sql="insert into addnews(news_name,news_des) values('$news','$des')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err10"]="News Added Successfully";
	header("location:addnews.php");
	
}
else
	echo mysql_error();

?>