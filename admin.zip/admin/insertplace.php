<?php
session_start();
include('config.php');
$city=mysql_real_escape_string($_REQUEST["n"]);
$place=mysql_real_escape_string($_REQUEST["nm"]);

if(empty($place))
{
	$_SESSION["pn"]="Enter Place Name";
	header("location:addplace.php");
}
else
{
$sql="insert into addplace(city,place_name) values('$city','$place')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err"]="Place Added Successfully";
	header("location:addplace.php");
	
}
else
	echo mysql_error();
}
?>