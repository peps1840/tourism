<?php
session_start();
include('headad.php');
?>


<form id='form1' action='insertplace.php' method='post'>
<fieldset  style='border:3px solid crimson;width:80%'>
<legend>ADD PLACE</legend>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' width='50%'>

<tr>
	<td colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		ADD PLACE
	
	</td>

</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	
	</td>

</tr>

<tr>
	<td colspan='2' align='center' style='color:red;font-weight:bold'>
		<?php
			if(isset($_SESSION["err"]))
				echo $_SESSION["err"];
		?>
	
	</td>

</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	
	</td>

</tr>

<tr>
<td>CITY NAME</td>
	<td style='color:red;font-weight:bold'>
	<?php
	
	include('config.php');
	$r=mysql_query("select state_name from add_state")
	?>
	
	<select name='n'>
	<?php
	while($row=mysql_fetch_array($r))
	{
		echo "<option  value='$row[0]'>$row[0]</option>";
	}
	?>	

	</select>
	
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	
<tr>
	<td>PLACE NAME</td>
	<td style='color:red;font-weight:bold'><input id='names' type='text' value='' name='nm'>
		<?php
			if(isset($_SESSION["pn"]))
				echo $_SESSION["pn"];
		?>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	

<tr align='center'>
	<td><input type='submit' value='send' ></td>
</tr>
	
	
</table>
</fieldset>
</form>
<?php
$_SESSION["err"]="";
$_SESSION["pn"]="";
include('footerad.php');
?>