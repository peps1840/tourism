<?php
	session_start();
	include('headad.php');
	
?>


<form action='insertnews.php' method='post' enctype='multipart/form-data'>
<fieldset  style='border:3px solid crimson;width:95%'>
<legend>ADD NEWS</legend>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' width='70%'>
<tr>
	<td colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		ADD NEWS
	
	</td>

</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>

<tr>
	<td  colspan='2'  align='center' style='color:red'>
		<?php
			if(isset($_SESSION["err10"]))
				echo $_SESSION["err10"];
		
		?>
	
	</td>

</tR>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>
<tr>
	<td>NEWS NAME</td>
	<td><input type='text' value='' name='a1' ></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>DESCRIPTION</td>
	<td><textarea rows=10 cols=30 name='add' ></textarea></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr align='center'>
	<td><input type='submit' value='send' ></td>
</tr>
	
	
</table>
</fieldset>
</form>
<?php
$_SESSION["err10"]="";
include('footerad.php');
?>