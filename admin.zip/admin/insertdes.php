<?php
ob_start();
session_start();
include('config.php');
$city=mysql_real_escape_string($_REQUEST["n1"]);
$place=mysql_real_escape_string($_REQUEST["t1"]);
$address=mysql_real_escape_string($_REQUEST["a1"]);
$r=move_uploaded_file($_FILES["photo"]["tmp_name"],"place_photo/".$_FILES["photo"]["name"]);

$a=$_FILES["photo"]["name"];
$des=mysql_real_escape_string($_REQUEST["add"]);

$sql="insert into adddes(city_name,place_name,address,photo,place_des) values('$city','$place','$address','$a','$des')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err1"]="Description Added Successfully";
	header("location:adddes.php");
	
}
else
	echo mysql_error();

?>