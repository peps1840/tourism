<?php
session_start();
include('config.php');

$city=mysql_real_escape_string($_REQUEST["n1"]);
$hotel=mysql_real_escape_string($_REQUEST["t1"]);
$address=mysql_real_escape_string($_REQUEST["a1"]);
$r=move_uploaded_file($_FILES["photo"]["tmp_name"],"place_photo/".$_FILES["photo"]["name"]);
$photo=mysql_real_escape_string($_REQUEST["photo"]);
$a=$_FILES["photo"]["name"];
$des=mysql_real_escape_string($_REQUEST["add"]);

$sql="insert into addhotel(city_name,hotel_name,address,photo,hotel_des) values('$city','$hotel','$address','$a','$des')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err5"]=" Added Successfully";
	header("location:addhotel.php");
	
}
else
	echo mysql_error();

?>