<?php
session_start();

?>


<form action='login.php' method='post'>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' >
<tr>
		<td colspan='2' align='center' id='top'>
			<img src="1.gif" height=150 width=1000 style='float:left'>
	
		</td>
		</tr>
<tr>
	<td colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		LOGIN
	
	</td>

</tr>

<tr>
	<td colspan='2'>
		&nbsp;
	
	</td>

</tr>
<tr>
	<td colspan='2' align='center' style='color:red;font-weight:bold'>
		<?php
			if(isset($_SESSION["err8"]))
				echo $_SESSION["err8"];
		?>
	
	</td>

</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	
	</td>

</tr>
<tr align='left'>
	<td><center>USER NAME</center></td>
	<td  style='color:red;font-weight:bold'><input type='text' value='' name='nm'>
		<?php
			if(isset($_SESSION["uname"]))
				echo $_SESSION["uname"];
		?>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	
<tr align='left'>
	<td><center>PASSWORD</center></td>
	<td  style='color:red;font-weight:bold'><input type='password' value='' name='pass'>
		<?php
			if(isset($_SESSION["pas"]))
				echo $_SESSION["pas"];
		?>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	

<tr align='center'>
	<td align='right'><center><input type='submit' value='login' ></center></td>
</tr>
<tr>
	<td  colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		DESIGN AND DEVELOPED BY LAKSHIT LOHAR</br>
	</td>
</tr>
	
	
</table>
</form>

<?php
$_SESSION["uname"]="";
$_SESSION["err8"]="";
$_SESSION["pas"]="";
?>