<?php
session_start();
include('config.php');
$id=$_POST["id"];
$city=mysql_real_escape_string($_REQUEST["n1"]);
$place=mysql_real_escape_string($_REQUEST["t1"]);
$address=mysql_real_escape_string($_REQUEST["a1"]);
$name=$_FILES["photo"]["name"];
if($name!="")
{
$r=move_uploaded_file($_FILES["photo"]["tmp_name"],"place_photo/".$_FILES["photo"]["name"]);
$photo=mysql_real_escape_string($_FILES["photo"]["name"]);
}
else
{
	
	$rr=mysql_query("select  photo  from adddes  where id='$id'");
	$rows=mysql_fetch_row($rr);
	$photo=$rows[0];
	
}
$des=mysql_real_escape_string($_REQUEST["add"]);



$sql="update adddes set city_name='$city', place_name='$place',address='$address',photo='$photo',place_des='$des'  where id='$id'";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err4"]="Updated Successfully";
	header("location:viewplace.php");
	
}
else
	echo mysql_error();

?>