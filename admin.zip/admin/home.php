<?php
include('headad.php');
?>
<h1><center>INCREDIBLE STATE OF INDIA</center></h1>
<p style='text-align:justify; width:950px; font-family:monotype corsiva; font-size:15pt '>Rajasthan, the desert state of India needs no introduction.
 Being one of the most colorful state of the country.Rajasthan India ranks very high on the list of travelers coming to India.
 The royal cultural heritage, ancient forts and palaces, colorful festivals, wildlife sanctuaries and lot more will surely enchant you with its charm. 
 Also explore rural villages of Rajasthan India, a truly enchanting experience. Check out the links provided in this section to learn more about Rajasthan travel and tourism and plan your own tours Rajasthan.
 Alternatively just pick up any Rajasthan travel package from the list offered below the links and leave the rest to us.</p>
 <p style='text-align:justify; width:950px; font-family:monotype corsiva; font-size:15pt '>
 If you are really intended to make your holidays special in Rajasthan, then Rajasthan tours is here to make it possible for you.
 Tour of Rajasthan offers exotic regal experience through its variegated  activities like camel safari on the sand dunes of Thar desert, wildlife 
 adventures, forts and palaces, temples, colorful fairs and festivals. Also get to taste the yummy Rajasthani food and meet the local Rajasthani people to know more about their culture and traditions.
 </p>


<?php

include('footerad.php');
?>