<?php
include('headad.php');
?>
<form action='insertstate.php' method='post'>
<table align='center'>
<tr>
	<td><select name='n'>
	<option value='

<?php
include('footerad.php');
?>