<?php
session_start();
include('config.php');
$city=mysql_real_escape_string($_REQUEST["n1"]);
$place=mysql_real_escape_string($_REQUEST["t1"]);
$r=move_uploaded_file($_FILES["photo"]["tmp_name"],"photo/".$_FILES["photo"]["name"]);
$photo=mysql_real_escape_string($_REQUEST["photo"]);
$a=$_FILES["photo"]["name"];


$sql="insert into addphoto(city_name,place_name,photo) values('$city','$place','$a')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err2"]="Photo Added Successfully";
	header("location:addphoto.php");
	
}
else
	echo mysql_error();

?>