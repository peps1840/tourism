<html>
	<head>
		<link rel="stylesheet" href="style.css">
	<style type="text/css">
		.pics {  
    height:  200px;  
    width:   1200px;  
    
	} 
 
.pics img {  
    
	width:  1300px; 
    height: 200px; 
    top:  0; 
    left: 0 
} 
		</style>

		<script type='text/javascript' src='js/jquery.js' >
		</script>
		<script type='text/javascript' src='js/cycle.js' >
		</script>
		<script language="javascript" type="text/javascript">
		$(document).ready(function()
		{
		
		$('.pics').cycle('turnDown');
		});
		
		</script>
		
		</head>	

		</head>
	<table border='0' cellpadding=0 width='80%' align='center' cellspacing='0' bordercolor='purple'>
		<tr>
		<td colspan='2' align='center' id='top'>
			<img src="1.gif" height=150 width=1300 style='float:left'>
	
		</td>
		</tr>
	<tr>
		<td colspan='2'>
			<div class="pics" > 
	
    <img src="images/1.jpg" width="1500" height="250" /> 
    <img src="images/2.jpg" width="1500" height="250" /> 
    <img src="images/3.jpg" width="1500" height="250" />
	<img src="images/4.jpg" width="1500" height="250" />



	
</div> 
		
		</td>
	
	</tr>

		<tr>
			<td colspan='2'>
				<table width='100%' align='center' class='ss'>
					<tr><td><a href='index.php'>LOGIN</a></td>
					<td><a href='home.php'> HOME</a></td>
					<td><a href='addplace.php'> ADD PLACES</a></td>
					<td><a href='adddes.php'> PLACE DESCRIPTION</a></td>
					<td><a href='addphoto.php'> ADD PHOTO</a></td>
					<td><a href='addhotel.php'> ADD HOTELS</a></td>
					<td><a href='weekand.php'> ADD WEEKEND PLACES</a></td>
					<td><a href='addnews.php'>ADD NEWS</a></td>
					<td><a href='viewplace.php'> VIEW PLACE</a></td>
					<td><a href='viewhotel.php'> VIEW HOTEL</a></td>
					<td><a href='logout.php'> LOGOUT</a></td>

					
				</table>
			</td>
		</tr>

		<tr >
					<td  width='80%' style='height:280px;overflow:both;background:white'align='center'>