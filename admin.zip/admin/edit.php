
<script>

function showCustomer(str)
{
var xmlhttp;

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("hint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","get_place.php?q="+str,true);
xmlhttp.send();
}
</script>


<?php
	include('headad.php');
	include('config.php');
	$id=$_GET["a"];
	
	$sql="select * from adddes where id='$id'";
	$r=mysql_query($sql);
	if($row=mysql_fetch_array($r))
	{
		$id=$row[0];
		$city_name=$row[1];
		$place_name=$row[2];
		$photos=$row[4];
		$place_address=$row[3];
		$place_des=$row[5];
	}
?>
<form action='update.php' method='post' enctype='multipart/form-data'>
<fieldset  style='border:2px solid black'>
<legend>ADD PLACE DESCRIPTION</legend>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' width='70%'>
<tr align='center'>
	<td colspan='2'>SELECT CITY</td>
</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>
<tr>
	<td  colspan='2'  align='center' style='color:red'>
		<input type='hidden'  name='id' value='<?php echo $id; ?>'>
	
	</td>

</tR>

<tr>
	<td>CITY NAME</td>
	<td><select name='n1' onchange='showCustomer(this.value)'>
	<option value='<?php echo $city_name ?>'><?php echo $city_name ?></option>
	<option value='ajmer'>AJMER</option>
	<option value='alwar'>ALWAR</option>
	<option value='banswara'>BANSWARA</option>
	<option value='baran'>BARAN</option>
	<option value='barmer'>BARMER</option>
	<option value='bharatpur'>BHARATPUR</option>
	<option value='bhilwara'>BHILWALRA</option>
	<option value='bikaner'>BIKANER</option>
	<option value='bundi'>BUNDI</option>
	<option value='chittorgarh'>CHITTORGARH</option>
	<option value='churu'>CHURU</option>
	<option value='dausa'>DAUSA</option>
	<option value='dholpur'>DHOLPUR</option>
	<option value='dungarpur'>DUNGARPUR</option>
	<option value='hanumangarh'>HANUMANGARH</option>
	<option value='jaipur'>JAIPUR</option>
	<option value='jaisalmer'>JAISALMER</option>
	<option value='jodhpur'>JODHPUR</option>
	<option value='kota'>KOTA</option>
	<option value='nagaur'>NAGAUR</option>
	<option value='pali'>PALI</option>
	<option value='sikar'>SIKAR</option>
	<option value='sirohi'>SIROHI</option>
	<option value='rajsamand'>RAJSAMAND</option>
	<option value='udaipur'>UDAIPUR</option>
	</select>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	
<tr>
	<td>PLACE NAME</td>
	<td id='hint'>
	
	<select name='t1'>
		<option  value='<?php echo $place_name ?>'><?php echo $place_name ?></option>
	<option  value='Select Place'>Select Place</option>
	
	
	</select>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>PLACE ADDRESS</td>
	<td><input type='text' name='a1' value='<?php echo $place_address ?>'></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>PHOTO</td>
	<td><image  src='place_photo/<?php  echo $photos; ?>'  height=100  width=100><input type='file' name='photo'></td>
</tr>	
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>DESCRIPTION</td>
	<td><textarea rows=10 cols=30 name='add' >
	
	<?php
	echo $place_des;
	
	?>
	</textarea></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr align='center'>
	<td><input type='submit' value='send' ></td>
</tr>
	
	
</table>
</fieldset>
</form>

<?php
include('footerad.php')
?>