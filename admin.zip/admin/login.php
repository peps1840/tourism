<?php
session_start();
include('config.php');
$user=mysql_real_escape_string($_REQUEST["nm"]);
$pass=mysql_real_escape_string($_REQUEST["pass"]);

if(empty($user)||empty($pass))
{
	if(empty($user))
		$_SESSION["uname"]="Enter Your User Name";
	if(empty($pass))
		$_SESSION["pas"]="Enter Your password";
	header("location:index.php");
}
else
{
	$sql="select * from login where username='$user' and password='$pass'";
	$r=mysql_query($sql);
	if($row=mysql_fetch_array($r))
	{
	$_SESSION["err8"]="you login successfully";
	header("location:home.php");
	
	}
	else
	{
		$_SESSION["err8"]="invalid UserName and Password";
		header("location:index.php");
	}
}
	
?>