<?php
	session_start();
	include('headad.php');
	
?>


<form action='inserthotel.php' method='post' enctype='multipart/form-data'>
<fieldset  style='border:3px solid crimson;width:80%'>
<legend>ADD HOTEL</legend>
<table align='center' bordercolor='salmon' cellspacing='0'border='0' width='70%'>
<tr>
	<td colspan='2'  style='background:moccasin;color:brown;text-align:center;font-weight:bold ;font-size:15pt'>
		ADD HOTEL
	
	</td>

</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>

<tr align='center'>
	<td colspan='2'>SELECT CITY</td>
</tr>
<tr>
	<td colspan='2'>&nbsp;</td>
</tr>
<tr>
	<td  colspan='2'  align='center' style='color:red'>
		<?php
			if(isset($_SESSION["err5"]))
				echo $_SESSION["err5"];
		
		?>
	
	</td>

</tR>

<tr>
	<td>CITY NAME</td>
	<td><select name='n1' onchange='showCustomer(this.value)'>
	<?php
	include('config.php');
	$r=mysql_query("select state_name from add_state");
	
	while($row=mysql_fetch_array($r))
	{
		echo "<option  value='$row[0]'>$row[0]</option>";
	}
?>	
	</select>
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>	
<tr>
	<td>HOTEL NAME</td>
	<td id='hint'>
	<input type='text' name='t1' value=''>	
	</td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>HOTEL ADDRESS</td>
	<td><textarea rows=5 cols=10 name='a1' ></textarea></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>PHOTO</td>
	<td><input type='file' name='photo'></td>
</tr>	
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr>
	<td>HOTEL DESCRIPTION</td>
	<td><textarea rows=10 cols=30 name='add' ></textarea></td>
</tr>
<tr>
	<td colspan='2'>
		&nbsp;
	</td>
</tr>
<tr align='center'>
	<td><input type='submit' value='send' ></td>
</tr>
	
	
</table>
</fieldset>
</form>
<?php
$_SESSION["err5"]="";
include('footerad.php');
?>