<?php
session_start();
include('config.php');
$id=$_GET["a"];
$sql=mysql_query("delete from addhotel where id='$id'");

if($sql)
{
	$_SESSION["err7"]="Delete Successfully";
	header("location:viewhotel.php");
}
?>

