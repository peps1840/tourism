<?php
session_start();
include('config.php');

$place=mysql_real_escape_string($_REQUEST["t1"]);

$r=move_uploaded_file($_FILES["photo"]["tmp_name"],"place_photo/".$_FILES["photo"]["name"]);
$photo=mysql_real_escape_string($_REQUEST["photo"]);
$a=$_FILES["photo"]["name"];

$sql="insert into weekand(place_name,photo) values('$place','$a')";
$r=mysql_query($sql);
if($r)
{
	$_SESSION["err9"]="places Added Successfully";
	header("location:weekand.php");
	
}
else
	echo mysql_error();

?>