<?php
session_start();
session_destroy();
$_SESSION["err8"]="you logout successfully";
	header("location:index.php");
?>